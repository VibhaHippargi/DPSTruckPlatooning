package Threading.Code;

public class Disconnectcounter {

    public int disconnected_client_node;

}
